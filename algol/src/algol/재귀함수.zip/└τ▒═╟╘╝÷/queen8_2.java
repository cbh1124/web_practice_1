package algol;

public class queen8_2 {
	// 한 열에 존재하는 퀸의 모든 가능성에서 필요없는 가능성을 배제 (한 열에는 퀸이 하나만 존재하면 된다) 
	static boolean[] flag = new boolean[8];		// 각 행에 퀸을 배치했는지 체크
	static int[] pos = new int[8];				// 각 열의 퀸의 위치
	
	// 각 열의 퀸의 위치를 출력합니다. 
	static void print() {
		for (int i = 0; i < 8; i++)
			System.out.printf("%2d", pos[i]);
		System.out.println();
	}

	// i열의 알맞은 위치에 퀸을 배치합니다. 
	static void set(int i) {
		for (int j = 0; j < 8; j++) {   // j에서 첫 배치를 해서 false[j]가 중복되지 않았다면 배치가 아직 안되었다면 1열에 배치가 안된거니까 중복체크 그다음열에서 중복체크 j는 한 행 
			if (flag[j] == false) {		// j행에는 퀸을 아직 배치하지 않았다면
				pos[i] = j;				// 퀸을 j행에 배치
				if (i == 7)				// 모든 열에 배치한 경우
					print();
				else {
					flag[j] = true;
					set(i + 1);
					flag[j] = false;
				}
			}
		}
	}

	public static void main(String[] args) {
		set(0);
	}
}
