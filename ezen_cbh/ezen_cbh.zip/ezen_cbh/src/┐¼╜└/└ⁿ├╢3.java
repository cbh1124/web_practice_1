package ����;

public class ��ö3 {
	private String value;
	
	public ��ö3(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	@Override 
	public String toString() {
		return this.value+"";
	}
}