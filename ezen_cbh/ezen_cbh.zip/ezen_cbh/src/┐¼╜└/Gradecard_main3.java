package ����;

import java.util.ArrayList;
import java.util.Scanner;

public class Gradecard_main3 {
	
	Scanner sc = new Scanner(System.in);
	ArrayList <Gradecard3> students = new ArrayList<>();
}
