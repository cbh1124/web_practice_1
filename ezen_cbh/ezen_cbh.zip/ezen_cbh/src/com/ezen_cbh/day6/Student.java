package com.ezen_cbh.day6;

public class Student {
	
}
