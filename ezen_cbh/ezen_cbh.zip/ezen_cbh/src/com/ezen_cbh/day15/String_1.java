package com.ezen_cbh.day15;

public class String_1 {
	
	String value;
	
	public String_1(String value) {
		this.value = value;
	} 
	
	@Override
	public String toString() {
		return this.value+"";
	}
}
