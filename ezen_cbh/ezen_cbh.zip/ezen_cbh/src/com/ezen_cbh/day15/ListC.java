package com.ezen_cbh.day15;

public class ListC {
	
	private String member;
	private int memberC;
	
	public ListC(String member, int memberC) {
		super();
		this.member = member;
		this.memberC = memberC;
	}

	public String getMember() {
		return member;
	}

	public void setMember(String member) {
		this.member = member;
	}

	public int getMemberC() {
		return memberC;
	}

	public void setMemberC(int memberC) {
		this.memberC = memberC;
	}

	
	
	
}
