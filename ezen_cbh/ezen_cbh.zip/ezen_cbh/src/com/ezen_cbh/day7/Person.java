package com.ezen_cbh.day7;

public class Person {
	// 1. �ʵ� 
	final String nation = "Korea";
	final String ssn;
	String name;
	
	// 2. ������
	public Person(String ssn, String name) {
		super();
		this.ssn = ssn;
		this.name = name;
	}
	
	
	
	
	
	// 3. �޼ҵ�
}
