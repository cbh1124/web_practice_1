package com.ezen_cbh.day11;

public class Car {
	public String model;
	
	public Car(String model) {
		this.model = model;
	}
}
