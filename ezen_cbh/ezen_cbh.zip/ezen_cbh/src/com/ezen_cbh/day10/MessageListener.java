package com.ezen_cbh.day10;



public class MessageListener implements Button.OnClickListener {
	@Override
	public void onClick() {
		// TODO Auto-generated method stub
		
	}
}
