package com.ezen_cbh.day10;

public interface Action {
	
	void work();
}
