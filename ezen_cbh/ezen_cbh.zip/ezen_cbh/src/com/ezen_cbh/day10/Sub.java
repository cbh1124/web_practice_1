package com.ezen_cbh.day10;

public class Sub extends Person {
	
	
}
