package com.ezen_cbh.day10;

public interface Vehicle {
	public void run();
		// 
}
