package com.ezen_cbh.day10;

public class Dog implements Soundable {
	@Override
	public String sound() {
		// TODO Auto-generated method stub
		return "�۸�";
	}
}
