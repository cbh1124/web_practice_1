package com.ezen_cbh.day14;

public class Student extends Person {
	
	
	public Student(String name) {
		super(name);
	}
}
