package com.ezen_cbh.day14;

public class Person {
	
	//�ʵ� 
	private String name;
	
	
	//������
	public Person() {
		// TODO Auto-generated constructor stub
	}
	
	public Person(String name) {
		
		this.name = name;
		
	}

	
	
	//�޼ҵ�
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
		
	
	@Override
	public String toString() {
		
		return super.toString();
	}
	
	
	
	
	
}


