package com.ezen_cbh.day14;

public class Worker extends Person {
	
	public Worker(String name) {
		
		super(name);
	}
}
