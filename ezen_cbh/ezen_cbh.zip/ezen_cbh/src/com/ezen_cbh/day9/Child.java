package com.ezen_cbh.day9;

public class Child extends Parent {
	private String name;
	
	public Child() {
		
	}
}
