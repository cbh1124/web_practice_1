package com.ezen_cbh.day9;

public class B {
	
	public void method() {
		A a = new A();
		a.field = "value";
		a.method();

	}
}
