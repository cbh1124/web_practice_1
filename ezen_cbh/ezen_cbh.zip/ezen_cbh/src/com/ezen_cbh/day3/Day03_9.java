package com.ezen_cbh.day3;

public class Day03_9 {
	public static void main(String[] args) {
		for(int i=0; i<=100; i=i+3) {
			System.out.println("" + i);
		}
	}
}
