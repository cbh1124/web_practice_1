package com.ezen_cbh.day9_1;

import com.ezen_cbh.day9.A;

public class C {
	public void method() {
		A a = new A();
		a.field = "value";
		a.method();

	}
}
