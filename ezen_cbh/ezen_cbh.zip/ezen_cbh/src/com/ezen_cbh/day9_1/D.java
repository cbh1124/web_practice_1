package com.ezen_cbh.day9_1;
import com.ezen_cbh.day9.A;

public class D extends A{
	public D() {
		super();
		this.field = "value";
		this.method();
		
	}
}
